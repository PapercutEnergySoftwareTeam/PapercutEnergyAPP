<?php
/**
 * Config File of The Template
 * Created by PhpStorm.
 * User: Tushar Khan
 * Date: 9/8/2017
 * Time: 6:52 AM
 */
?>

<?php
    define('DB_NAME', 'ecom');
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
?>