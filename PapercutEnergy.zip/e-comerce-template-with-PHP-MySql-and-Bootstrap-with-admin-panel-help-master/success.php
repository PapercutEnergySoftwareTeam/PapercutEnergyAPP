<?php
/**
 * Created by PhpStorm.
 * User: Tanjil Hasan
 * Date: 9/21/2017
 * Time: 7:37 PM
 */
?>

<?php
    include "header.php";
?>
    <!--banner-->
    <div class="banner banner10">
        <div class="container">
            <h2>Payment Complete</h2>
        </div>
    </div>
    <!--//banner-->
    <!-- breadcrumbs -->
    <div class="breadcrumb_dress">
        <div class="container">
            <ul>
                <li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a> <i>/</i></li>
                <li>Success</li>
            </ul>
        </div>
    </div>
    <!-- //breadcrumbs -->

    <div class="single">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-sm-10 col-xs-10 col-lg-10 text-center">
                    <h4>Your Order has been taken successfully , We will Contact you Soon</h4>
                    <h4>Go to Home Page <a class="btn btn-warning" href="index.php">Home</a> </h4>
                </div>
            </div>
        </div>
    </div>

<?php
    include "footer.php";
?>
