<?php
/**
 * Created by PhpStorm.
 * User: Tushar Khan
 * Date: 9/25/2017
 * Time: 4:35 PM
 */
?>
<!--<script>window.location = '' </script>-->
<?php

    header("location:http://localhost/MVC/");

?>